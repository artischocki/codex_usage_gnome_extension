import Adw from 'gi://Adw';
import Gtk from 'gi://Gtk';
import Gio from 'gi://Gio';

import {ExtensionPreferences} from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

export default class CodexUsagePreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();

        const page = new Adw.PreferencesPage({
            title: 'Codex Usage',
            icon_name: 'utilities-terminal-symbolic',
        });
        window.add(page);

        const generalGroup = new Adw.PreferencesGroup({
            title: 'General',
            description: 'Configure how the extension fetches and displays Codex usage.',
        });
        page.add(generalGroup);

        const refreshRow = new Adw.SpinRow({
            title: 'Refresh interval',
            subtitle: 'How often to request usage from the Codex backend, in seconds.',
            adjustment: new Gtk.Adjustment({
                lower: 15,
                upper: 900,
                step_increment: 15,
                page_increment: 60,
                value: settings.get_int('refresh-interval'),
            }),
        });
        settings.bind('refresh-interval', refreshRow, 'value', Gio.SettingsBindFlags.DEFAULT);
        generalGroup.add(refreshRow);

        const authRow = new Adw.EntryRow({
            title: 'Auth file',
            show_apply_button: true,
        });
        authRow.set_text(settings.get_string('auth-file'));
        authRow.connect('apply', () => {
            settings.set_string('auth-file', authRow.get_text());
        });
        generalGroup.add(authRow);

        const authHint = new Gtk.Label({
            label: 'Leave empty to use ~/.codex/auth.json',
            xalign: 0,
            css_classes: ['dim-label', 'caption'],
            margin_start: 12,
            margin_top: 4,
        });
        generalGroup.add(authHint);

        const panelGroup = new Adw.PreferencesGroup({
            title: 'Panel display',
            description: 'Choose how 5-hour usage appears in the top bar.',
        });
        page.add(panelGroup);

        const displayModeRow = new Adw.ComboRow({
            title: 'Display mode',
            subtitle: 'Show a number, a progress bar, or both.',
        });
        const displayModel = new Gtk.StringList();
        displayModel.append('Text');
        displayModel.append('Progress bar');
        displayModel.append('Both');
        displayModeRow.set_model(displayModel);
        displayModeRow.set_selected(this._displayModeIndex(settings.get_string('display-mode')));
        displayModeRow.connect('notify::selected', () => {
            settings.set_string('display-mode', ['text', 'bar', 'both'][displayModeRow.get_selected()]);
        });
        panelGroup.add(displayModeRow);

        const usageMetricRow = new Adw.ComboRow({
            title: 'Usage metric',
            subtitle: 'Show percentages as used or left.',
        });
        const usageMetricModel = new Gtk.StringList();
        usageMetricModel.append('Used');
        usageMetricModel.append('Left');
        usageMetricRow.set_model(usageMetricModel);
        usageMetricRow.set_selected(settings.get_string('usage-metric') === 'left' ? 1 : 0);
        usageMetricRow.connect('notify::selected', () => {
            settings.set_string('usage-metric', usageMetricRow.get_selected() === 1 ? 'left' : 'used');
        });
        panelGroup.add(usageMetricRow);

        const showIconRow = new Adw.SwitchRow({
            title: 'Show icon',
            subtitle: 'Display a terminal icon next to the usage indicator.',
        });
        settings.bind('show-icon', showIconRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        panelGroup.add(showIconRow);

        const timeFormatRow = new Adw.ComboRow({
            title: 'Reset time format',
            subtitle: 'Choose whether reset times use a 24-hour or 12-hour clock.',
        });
        const timeFormatModel = new Gtk.StringList();
        timeFormatModel.append('24-hour');
        timeFormatModel.append('12-hour');
        timeFormatRow.set_model(timeFormatModel);
        timeFormatRow.set_selected(settings.get_string('time-format') === '12h' ? 1 : 0);
        timeFormatRow.connect('notify::selected', () => {
            settings.set_string('time-format', timeFormatRow.get_selected() === 1 ? '12h' : '24h');
        });
        panelGroup.add(timeFormatRow);

        const dateFormatRow = new Adw.ComboRow({
            title: '7-day date format',
            subtitle: 'Choose how the date is shown for the 7-day reset time.',
        });
        const dateFormatModel = new Gtk.StringList();
        dateFormatModel.append('Mar 15');
        dateFormatModel.append('15 Mar');
        dateFormatModel.append('03/15');
        dateFormatModel.append('15/03');
        dateFormatRow.set_model(dateFormatModel);
        dateFormatRow.set_selected(this._dateFormatIndex(settings.get_string('date-format')));
        dateFormatRow.connect('notify::selected', () => {
            settings.set_string('date-format', ['month-day', 'day-month', 'month/day', 'day/month'][dateFormatRow.get_selected()]);
        });
        panelGroup.add(dateFormatRow);

        const showCodeReviewRow = new Adw.SwitchRow({
            title: 'Show code review',
            subtitle: 'Include the Code Review usage section in the menu.',
        });
        settings.bind('show-code-review', showCodeReviewRow, 'active', Gio.SettingsBindFlags.DEFAULT);
        panelGroup.add(showCodeReviewRow);

        const panelSideRow = new Adw.ComboRow({
            title: 'Panel side',
            subtitle: 'Place the extension on the left or right side of the top bar.',
        });
        const panelSideModel = new Gtk.StringList();
        panelSideModel.append('Right');
        panelSideModel.append('Left');
        panelSideRow.set_model(panelSideModel);
        panelSideRow.set_selected(settings.get_string('panel-side') === 'left' ? 1 : 0);
        panelSideRow.connect('notify::selected', () => {
            settings.set_string('panel-side', panelSideRow.get_selected() === 1 ? 'left' : 'right');
        });
        panelGroup.add(panelSideRow);

        const networkGroup = new Adw.PreferencesGroup({
            title: 'Network',
            description: 'Optional proxy settings for the usage request.',
        });
        page.add(networkGroup);

        const proxyRow = new Adw.EntryRow({
            title: 'Proxy URL',
            show_apply_button: true,
        });
        proxyRow.set_text(settings.get_string('proxy-url'));
        proxyRow.connect('apply', () => {
            settings.set_string('proxy-url', proxyRow.get_text());
        });
        networkGroup.add(proxyRow);

        const proxyHint = new Gtk.Label({
            label: 'Example: http://localhost:8080. Leave empty for direct access.',
            xalign: 0,
            css_classes: ['dim-label', 'caption'],
            margin_start: 12,
            margin_top: 4,
        });
        networkGroup.add(proxyHint);
    }

    _displayModeIndex(mode) {
        if (mode === 'bar') {
            return 1;
        }
        if (mode === 'both') {
            return 2;
        }
        return 0;
    }

    _dateFormatIndex(format) {
        if (format === 'day-month') {
            return 1;
        }
        if (format === 'month/day') {
            return 2;
        }
        if (format === 'day/month') {
            return 3;
        }
        return 0;
    }
}
